import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите строку: ");
        String input = scanner.nextLine();
        String[] words = input.split(" ");
        int count = words.length;
        System.out.println("Количество слов в строке: " + count);
        System.out.print("Слова длиннее трех символов: ");
        for (String word : words) {
            if (word.length() > 3) {
                System.out.print(word + " ");
            }
        }
    }
}